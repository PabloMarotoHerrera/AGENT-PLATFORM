﻿import omni.ext
import omni.kit.actions.core
import carb

from .mesh_actions import register_actions, deregister_actions


class PrimitiveMeshExtension(omni.ext.IExt):
    def __init__(self):
        super().__init__()
        self._ext_name = None
        self._mesh_generator = None

    def on_startup(self, ext_id):
        self._ext_name = ext_id
        carb.log_info(f"[Custom Mesh] self._ext_name = {self._ext_name}")

        # 1) UI / generator
        try:
            from .generator import MeshGenerator
            self._mesh_generator = MeshGenerator()
            self._mesh_generator.register_menu()

            omni.kit.actions.core.get_action_registry().register_action(
                ext_id,
                "show_setting_window",
                self._mesh_generator.show_setting_window,
                display_name="Custom Mesh Settings",
                description="Open the custom mesh generator UI",
                tag="Custom Mesh"
            )
        except Exception as e:
            carb.log_error(f"[Custom Mesh] Error creando MeshGenerator: {e}")

        register_actions("custom.kit.primitive.mesh", PrimitiveMeshExtension, lambda: self._mesh_generator)

    def on_shutdown(self):
        if self._mesh_generator:
            self._mesh_generator.destroy()
            self._mesh_generator = None
        deregister_actions(self._ext_name)
