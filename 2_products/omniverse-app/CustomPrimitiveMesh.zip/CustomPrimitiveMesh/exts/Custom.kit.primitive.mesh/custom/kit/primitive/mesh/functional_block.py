﻿# -*- coding: utf-8 -*-

from pxr import UsdGeom, UsdShade, Sdf, Gf, Usd
import omni.usd


def create_material(stage):
    material_path = "/World/Materials/Glass"
    material = UsdShade.Material.Define(stage, material_path)
    return material


def _create_surfaces(stage, root_path, width, depth, height, scale, angles, translate):
    if stage.GetPrimAtPath(root_path).IsValid():
        stage.RemovePrim(root_path)

    root = UsdGeom.Xform.Define(stage, root_path)

    half_w, half_d, half_h = width / 2, depth / 2, height / 2

    surfaces_data = [
        ("Floor",      Gf.Vec3f(-half_w, -half_d, -half_h), Gf.Vec3f(width, 0, 0),   Gf.Vec3f(0, depth, 0)),
        ("Ceiling",    Gf.Vec3f(-half_w, -half_d,  half_h), Gf.Vec3f(width, 0, 0),   Gf.Vec3f(0, depth, 0)),
        ("Wall_Back",  Gf.Vec3f(-half_w, -half_d, -half_h), Gf.Vec3f(0, 0, height),  Gf.Vec3f(0, depth, 0)),
        ("Wall_Front", Gf.Vec3f( half_w, -half_d, -half_h), Gf.Vec3f(0, 0, height),  Gf.Vec3f(0, depth, 0)),
        ("Wall_Left",  Gf.Vec3f(-half_w, -half_d, -half_h), Gf.Vec3f(width, 0, 0),   Gf.Vec3f(0, 0, height)),
        ("Wall_Right", Gf.Vec3f(-half_w,  half_d, -half_h), Gf.Vec3f(width, 0, 0),   Gf.Vec3f(0, 0, height)),
    ]

    material = create_material(stage)

    for name, local_origin, u, v in surfaces_data:
        points = [
            local_origin,
            local_origin + u,
            local_origin + u + v,
            local_origin + v
        ]

        mesh = UsdGeom.Mesh.Define(stage, f"{root_path}/{name}")
        mesh.CreatePointsAttr(points)
        mesh.CreateFaceVertexCountsAttr([4])
        mesh.CreateFaceVertexIndicesAttr([0, 1, 2, 3])
        mesh.CreateExtentAttr([Gf.Vec3f(-1), Gf.Vec3f(1)])
        mesh.CreateDisplayColorAttr([Gf.Vec3f(0.0, 0.0, 0.0)])

        mesh.GetPrim().CreateAttribute("surfaceType", Sdf.ValueTypeNames.String).Set("Wall")
        mesh.GetPrim().CreateAttribute("boundaryCondition", Sdf.ValueTypeNames.String).Set("Outdoors")

        UsdShade.MaterialBindingAPI(mesh).Bind(material)

    xform = UsdGeom.Xformable(root)
    translate_op = xform.AddXformOp(UsdGeom.XformOp.TypeTranslate, UsdGeom.XformOp.PrecisionDouble, "")
    rotate_op = xform.AddXformOp(UsdGeom.XformOp.TypeRotateXYZ, UsdGeom.XformOp.PrecisionDouble, "")
    scale_op = xform.AddXformOp(UsdGeom.XformOp.TypeScale, UsdGeom.XformOp.PrecisionDouble, "")

    translate_op.Set(Gf.Vec3d(translate))
    rotate_op.Set(Gf.Vec3f(angles))
    scale_op.Set(Gf.Vec3f(scale))

    return root


def create_functional_block_from_visual():
    base_zone_path = "/World/FunctionalBlock/ThermalZone"
    stage = omni.usd.get_context().get_stage()
    thermal_zone_prim = stage.GetPrimAtPath(base_zone_path)
    if not thermal_zone_prim.IsValid():
        UsdGeom.Xform.Define(stage, base_zone_path)
    else:
        for child in thermal_zone_prim.GetChildren():
            if child.IsValid():
                stage.RemovePrim(child.GetPath())

    stage = omni.usd.get_context().get_stage()
    selection = omni.usd.get_context().get_selection()
    paths = selection.get_selected_prim_paths()

    if not paths:
        print("[FunctionalBlock] No prim seleccionado.")
        return

    prim = stage.GetPrimAtPath(paths[0])
    if not prim or not prim.IsValid():
        print("[FunctionalBlock] Prim no válido.")
        return

    try:
        size_attr = prim.GetAttribute("extent").Get()
        scale = prim.GetAttribute("xformOp:scale").Get()
        translate = prim.GetAttribute("xformOp:translate").Get()

        xform_api = UsdGeom.Xformable(prim)
        ops = xform_api.GetOrderedXformOps()
        angles = Gf.Vec3f(0.0)

        for op in ops:
            if op.GetOpType() == UsdGeom.XformOp.TypeRotateXYZ:
                angles = Gf.Vec3f(*op.Get())
                break

        partition_prim = prim.GetChild("PartitionPlane")
        partition_x = None

        if partition_prim and partition_prim.IsValid():
            part_translate = partition_prim.GetAttribute("xformOp:translate").Get()
            partition_x = part_translate[0]

        width = (size_attr[1][0] - size_attr[0][0])
        depth = (size_attr[1][1] - size_attr[0][1])
        height = (size_attr[1][2] - size_attr[0][2])

        if partition_x is not None:
            half_width = width / 2
            left_width = partition_x - (-half_width)
            right_width = width - left_width

            zones = [
                ("Zone0", left_width, -(width / 2 - left_width / 2)),
                ("Zone1", right_width, (width / 2 - right_width / 2))
            ]

            rotation_matrix = Gf.Matrix4d().SetRotate(
                Gf.Rotation(Gf.Vec3d(1, 0, 0), angles[0]) *
                Gf.Rotation(Gf.Vec3d(0, 1, 0), angles[1]) *
                Gf.Rotation(Gf.Vec3d(0, 0, 1), angles[2])
            )

            for name, zone_width, offset_x in zones:
                offset = Gf.Vec3d(offset_x * scale[0], 0, 0)
                offset_rotated = rotation_matrix.Transform(offset)
                zone_translate = Gf.Vec3d(translate) + offset_rotated
                zone_path = f"{base_zone_path}/{name}"
                _create_surfaces(stage, zone_path, zone_width, depth, height, scale, angles, zone_translate)

            print("[FunctionalBlock] Zonas funcionales generadas.")
            return

        rotation_matrix = Gf.Matrix4d().SetRotate(
            Gf.Rotation(Gf.Vec3d(1, 0, 0), angles[0]) *
            Gf.Rotation(Gf.Vec3d(0, 1, 0), angles[1]) *
            Gf.Rotation(Gf.Vec3d(0, 0, 1), angles[2])
        )
        zone_path = f"{base_zone_path}/Zone0"
        _create_surfaces(stage, zone_path, width, depth, height, scale, angles, translate)
        print(f"[FunctionalBlock] Zona funcional única creada en {zone_path}.")

    except Exception as e:
        print(f"[FunctionalBlock] Error al leer atributos del prim: {e}")
        return


def update_functional_block():
    create_functional_block_from_visual()


def toggle_functional_block_visibility():
    stage = omni.usd.get_context().get_stage()
    root_prim = stage.GetPrimAtPath("/World/FunctionalBlock/ThermalZone/Space")

    if not root_prim or not root_prim.IsValid():
        print("[FunctionalBlock] No existe el bloque funcional.")
        return

    xform = UsdGeom.Imageable(root_prim)
    visibility_attr = xform.GetVisibilityAttr()
    current_visibility = visibility_attr.Get()

    if current_visibility == UsdGeom.Tokens.invisible:
        xform.MakeVisible()
        print("[FunctionalBlock] Visibilidad activada.")
    else:
        xform.MakeInvisible()
        print("[FunctionalBlock] Visibilidad desactivada.")
