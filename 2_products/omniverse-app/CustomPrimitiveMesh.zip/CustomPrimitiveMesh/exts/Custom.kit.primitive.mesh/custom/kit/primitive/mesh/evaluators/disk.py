from .utils import get_int_setting, build_int_slider, generate_disk
from .abstract_shape_evaluator import AbstractShapeEvaluator
from pxr import Gf


class DiskEvaluator(AbstractShapeEvaluator):
    SETTING_RADIUS = "/persistent/app/mesh_generator/shapes/disk/radius"
    SETTING_U_SCALE = "/persistent/app/mesh_generator/shapes/disk/u_scale"
    SETTING_V_SCALE = "/persistent/app/mesh_generator/shapes/disk/v_scale"

    def __init__(self, attributes: dict):
        super().__init__(attributes)

    def eval(self, **kwargs):
        radius = get_int_setting(self.SETTING_RADIUS, 50)
        scale = radius

        num_u_verts_scale = kwargs.get("u_verts_scale", get_int_setting(self.SETTING_U_SCALE, 1))
        num_v_verts_scale = kwargs.get("v_verts_scale", get_int_setting(self.SETTING_V_SCALE, 1))

        up_axis = kwargs.get("up_axis", "Y")
        origin = Gf.Vec3f(0.0)

        u_patches = kwargs.get("u_patches", 32) * num_u_verts_scale
        v_patches = kwargs.get("v_patches", 1) * num_v_verts_scale

        u_patches = max(int(u_patches), 3)
        v_patches = max(int(v_patches), 1)

        center_point = Gf.Vec3f(0.0)
        return generate_disk(center_point, u_patches, v_patches, origin, scale, up_axis)

    @staticmethod
    def build_setting_ui():
        from omni import ui
        DiskEvaluator._radius_slider = build_int_slider(
            "Radius", DiskEvaluator.SETTING_RADIUS, 50, 10, 1000
        )
        ui.Spacer(height=5)

        DiskEvaluator._u_scale_slider = build_int_slider(
            "U Verts Scale", DiskEvaluator.SETTING_U_SCALE, 1, 1, 10
        )
        ui.Spacer(height=5)

        DiskEvaluator._v_scale_slider = build_int_slider(
            "V Verts Scale", DiskEvaluator.SETTING_V_SCALE, 1, 1, 10
        )

    @staticmethod
    def reset_setting():
        DiskEvaluator._radius_slider.set_value(50)
        DiskEvaluator._u_scale_slider.set_value(1)
        DiskEvaluator._v_scale_slider.set_value(1)
