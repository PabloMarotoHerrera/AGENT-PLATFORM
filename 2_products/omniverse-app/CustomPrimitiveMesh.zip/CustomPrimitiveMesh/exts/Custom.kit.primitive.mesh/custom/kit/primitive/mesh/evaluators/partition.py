import omni.usd
from pxr import Gf
from .abstract_shape_evaluator import AbstractShapeEvaluator
from .utils import generate_plane


class PartitionEvaluator(AbstractShapeEvaluator):
    def __init__(self, attributes: dict):
        super().__init__(attributes)

    def eval(self, **kwargs):
        # Recogemos los valores enviados desde partition_generator.py
        width = kwargs.get("width", 100.0)
        height = kwargs.get("height", 100.0)
        depth = kwargs.get("depth", 100.0)
        origin = kwargs.get("origin", Gf.Vec3f(0.0))
        up_axis = kwargs.get("up_axis", "X")
        u_patches = kwargs.get("u_patches", 1)
        v_patches = kwargs.get("v_patches", 1)

        # Convertimos a half_scale para el generador
        half_scale = [width * 0.5, height * 0.5, depth * 0.5]

        return generate_plane(origin, half_scale, u_patches, v_patches, up_axis)

    @staticmethod
    def build_setting_ui():
        pass

    @staticmethod
    def reset_setting():
        pass
