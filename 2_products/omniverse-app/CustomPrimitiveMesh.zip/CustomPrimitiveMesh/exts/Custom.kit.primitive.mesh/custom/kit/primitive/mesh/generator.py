import carb
import carb.settings
import omni
import omni.kit
from omni import ui
from .evaluators import _get_all_evaluators, get_geometry_mesh_prim_list
from omni.kit.menu.utils import MenuItemDescription, remove_menu_items, add_menu_items
from .functional_block import create_functional_block_from_visual, update_functional_block, toggle_functional_block_visibility
from .usd_to_idf import UsdToIdfExtension
from .partition_generator import create_partition_from_visual
import omni.usd
from pxr import UsdGeom, Gf
from pxr import UsdGeom
from .create_aperture import create_aperture
import omni.kit.app


def _get_selected_prim(stage):
    sel = omni.usd.get_context().get_selection().get_selected_prim_paths()
    if not sel:
        print("⚠️ Selecciona un muro (Mesh).")
        return None
    prim = stage.GetPrimAtPath(sel[0])
    return prim if prim and prim.IsValid() else None

def _mesh_center_and_normal(mesh_prim):
    mesh = UsdGeom.Mesh(mesh_prim)
    pts = mesh.GetPointsAttr().Get() or []
    if len(pts) < 3:
        return None, None

    # centro por bbox local (simple)
    bbox = UsdGeom.Boundable(mesh_prim).ComputeWorldBound(0.0, UsdGeom.Tokens.default_)
    box = bbox.GetBox()
    c = box.GetCenter()

    # normal heurística: si todos los x ~ const → normal ±X, si y const → ±Y, si z const → ±Z
    xs = [float(p[0]) for p in pts]
    ys = [float(p[1]) for p in pts]
    zs = [float(p[2]) for p in pts]

    def is_const(arr, tol=1e-4):
        return max(arr) - min(arr) < tol

    if is_const(xs):
        n = Gf.Vec3f(1, 0, 0)
    elif is_const(ys):
        n = Gf.Vec3f(0, 1, 0)
    elif is_const(zs):
        n = Gf.Vec3f(0, 0, 1)
    else:
        n = Gf.Vec3f(0, 1, 0)  # fallback

    return Gf.Vec3f(c[0], c[1], c[2]), n


def set_stage_up_axis_z():
    stage = omni.usd.get_context().get_stage()
    current_up_axis = UsdGeom.GetStageUpAxis(stage)
    if current_up_axis != UsdGeom.Tokens.z:
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
        print("🔄 Stage orientado a Z-up")

class MeshGenerator:
    def __init__(self):
        self._settings = carb.settings.get_settings()
        self._window = None
        self._mesh_setting_ui = {}
        self._current_setting_index = 0
        self._mesh_menu_list = []
        self._idf_exporter = UsdToIdfExtension()





    def register_menu(self):
        sub_menu = []
        for prim in get_geometry_mesh_prim_list():
            sub_menu.append(MenuItemDescription(name=prim, onclick_action=("custom.kit.primitive.mesh", f"create_mesh_prim_{prim.lower()}")))

        sub_menu.append(MenuItemDescription())
        sub_menu.append(MenuItemDescription(name="Custom Settings", onclick_action=("custom.kit.primitive.mesh", "show_setting_window")))

        self._mesh_menu_list = [
            MenuItemDescription(name="Custom Mesh", glyph="menu_prim.svg", sub_menu=sub_menu)
        ]
        add_menu_items(self._mesh_menu_list, "Create")

    def on_primitive_type_selected(self, model, item):
        names = get_geometry_mesh_prim_list()
        old_mesh_name = names[self._current_setting_index]
        if old_mesh_name in self._mesh_setting_ui:
            self._mesh_setting_ui[old_mesh_name].visible = False

        idx = model.get_item_value_model().as_int
        mesh_name = names[idx]
        if mesh_name in self._mesh_setting_ui:
            self._mesh_setting_ui[old_mesh_name].visible = False
            self._mesh_setting_ui[mesh_name].visible = True

        self._current_setting_index = idx

    def show_setting_window(self):
        flags = ui.WINDOW_FLAGS_NO_COLLAPSE | ui.WINDOW_FLAGS_NO_SCROLLBAR

        if not self._window:
            self._window = ui.Window(
                "Mesh Generation Settings",
                ui.DockPreference.DISABLED,
                width=600,
                height=540,
                flags=flags,
                padding_x=10,
                padding_y=10,
            )

            with self._window.frame:
                ui.Spacer(height=8)
                ui.Label("Aperturas", style={"font_size": 14, "color": 0xFFFFA500})

                with ui.HStack():
                    ui.Label("Ancho", width=60); w_f = ui.FloatField(); w_f.model.set_value(1.2)
                    ui.Label("Alto", width=50); h_f = ui.FloatField(); h_f.model.set_value(1.2)

                with ui.HStack():
                    ui.Label("Antepecho", width=80); sill_f = ui.FloatField(); sill_f.model.set_value(1.0)

                def _add_window():
                    stage = omni.usd.get_context().get_stage()
                    prim = _get_selected_prim(stage)
                    if not prim or not prim.IsA(UsdGeom.Mesh):
                        print("⚠️ Selecciona un Mesh (un muro).")
                        return
                    center, normal = _mesh_center_and_normal(prim)
                    if center is None:
                        return
                    create_aperture(
                        type_="window",
                        center=center,
                        width=w_f.model.get_value_as_float(),
                        height=h_f.model.get_value_as_float(),
                        sill=sill_f.model.get_value_as_float(),
                        normal=normal
                    )

                ui.Button("Añadir ventana (centro muro)", clicked_fn=_add_window)

                with ui.VStack(height=0, spacing=8):
                    ui.Spacer(height=10)
                    with ui.HStack():
                        ui.Label("Primitive Type", name="text", width=100)
                        model = ui.ComboBox(0, *get_geometry_mesh_prim_list(), name="primitive_type").model
                        model.add_item_changed_fn(self.on_primitive_type_selected)

                    ui.Separator()

                    with ui.ZStack():
                        mesh_names = get_geometry_mesh_prim_list()
                        for i in range(len(mesh_names)):
                            mesh_name = mesh_names[i]
                            stack = ui.VStack(spacing=4)
                            self._mesh_setting_ui[mesh_name] = stack
                            with stack:
                                evaluator_class = _get_all_evaluators()[mesh_name]
                                evaluator_class.build_setting_ui()
                            if i != 0:
                                stack.visible = False

                    with ui.HStack():
                        ui.Spacer()
                        ui.Button("Create", width=140, height=0, mouse_pressed_fn=lambda *args: self._create_shape())
                        ui.Button("Reset Settings", width=140, height=0, mouse_pressed_fn=self._reset_settings)
                        ui.Spacer()

                        ui.Separator()
                        ui.Label("Bloque Funcional", height=20, style={"font_size": 16})
                    with ui.HStack():
                        ui.Button("Generar bloque funcional", width=140, clicked_fn=create_functional_block_from_visual)
                        ui.Button("Actualizar bloque funcional", width=140, clicked_fn=update_functional_block)
                        ui.Button("Mostrar/Ocultar bloque funcional", width=140, clicked_fn=toggle_functional_block_visibility)

                    ui.Separator()
                    ui.Label("Exportar IDF", height=20, style={"font_size": 16})
                    with ui.HStack():
                        ui.Button("Exportar a IDF", width=140, clicked_fn=self._idf_exporter.export_to_idf)
                        ui.Button("Simular", width=140, clicked_fn=self._idf_exporter.run_energyplus)

                    ui.Separator()
                    ui.Label("Zonificación", height=20, style={"font_size": 16})
                    with ui.HStack():
                        ui.Button("Añadir particion", width=140, clicked_fn=create_partition_from_visual)
                  
            self._current_setting_index = 0
        self._window.visible = True

    def _create_shape(self):
        set_stage_up_axis_z()  # 🔁 Asegura que el stage esté en Z-up antes de crear el mesh

        names = get_geometry_mesh_prim_list()
        mesh_type = names[self._current_setting_index]
        usd_context = omni.usd.get_context()
        with omni.kit.usd.layers.active_authoring_layer_context(usd_context):
            omni.kit.commands.execute("custom.kit.primitive.mesh.command.CreateMeshPrimWithCustomXform", prim_type=mesh_type, above_ground=True)

    def _reset_settings(self):
        names = get_geometry_mesh_prim_list()
        mesh_type = names[self._current_setting_index]
        evaluator_class = _get_all_evaluators()[mesh_type]
        evaluator_class.reset_setting()
