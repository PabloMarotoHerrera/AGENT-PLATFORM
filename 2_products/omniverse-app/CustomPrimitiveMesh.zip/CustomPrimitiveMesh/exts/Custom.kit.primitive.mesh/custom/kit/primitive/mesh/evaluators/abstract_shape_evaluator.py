from typing import List, Tuple
from pxr import Gf


class AbstractShapeEvaluator:  # pragma: no cover

    def __init__(self, attributes: dict):
        self._attributes = attributes

    def eval(self, **kwargs) -> Tuple[
        List[Gf.Vec3f], List[Gf.Vec3f],
        List[Gf.Vec2f], List[int], List[int]
    ]:
        """It must be implemented to return tuple
        [points, normals, uvs, face_indices, face_vertex_counts], where:
        * points and normals are array of Gf.Vec3f.
        * uvs are array of Gf.Vec2f that represents uv coordinates.
        * face_indexes are array of int that represents face indices.
        * face_vertex_counts are array of int that represents vertex count per face.
        * Normals and uvs must be face varying.
        """
        raise NotImplementedError("Eval must be implemented for this shape.")

    @staticmethod
    def build_setting_ui():
        pass

    @staticmethod
    def reset_setting():
        pass

    @staticmethod
    def get_default_half_scale():
        return 50
