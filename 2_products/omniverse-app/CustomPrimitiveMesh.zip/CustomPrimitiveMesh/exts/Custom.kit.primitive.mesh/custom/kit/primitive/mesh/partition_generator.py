﻿import omni.usd
from pxr import UsdGeom, Gf
import omni.kit.commands


def create_partition_from_visual():
    print("[PartitionGen] Iniciando creación de partición desde visual mesh")

    stage = omni.usd.get_context().get_stage()
    selection = omni.usd.get_context().get_selection().get_selected_prim_paths()

    if not selection:
        print("❌ No hay ningún prim seleccionado.")
        return

    prim_path = selection[0]
    visual_prim = stage.GetPrimAtPath(prim_path)

    if not visual_prim or not visual_prim.IsValid():
        print("❌ Prim no válido.")
        return

    # Usamos bounding box mundial para precisión real
    bbox = UsdGeom.Boundable(visual_prim).ComputeWorldBound(0.0, "default")
    box = bbox.GetBox()

    min_pt = box.GetMin()
    max_pt = box.GetMax()

    width = max_pt[0] - min_pt[0]
    depth = max_pt[1] - min_pt[1]
    height = max_pt[2] - min_pt[2]

    mid_x = (max_pt[0] + min_pt[0]) / 2.0
    center_y = (max_pt[1] + min_pt[1]) / 2.0
    center_z = (max_pt[2] + min_pt[2]) / 2.0

    plane_path = prim_path + "/PartitionPlane"

    result = omni.kit.commands.execute(
        "custom.kit.primitive.mesh.command.CreateMeshPrimWithCustomXform",
        prim_type="Partition",
        prim_path=plane_path,
        up_axis="X",
        above_ground=False,
        width=width,
        height=height,
        depth=depth
    )

    partition_prim = stage.GetPrimAtPath(plane_path)

    if not partition_prim or not partition_prim.IsValid():
        print("❌ No se pudo crear el plano de partición.")
        return

    xform = UsdGeom.Xformable(partition_prim)
    xform.ClearXformOpOrder()

    # Ajustamos completamente a las dimensiones del visual mesh
    xform.AddScaleOp().Set(Gf.Vec3f(0.01, height, depth))  # X: grosor mínimo
    xform.AddTranslateOp().Set(Gf.Vec3f(mid_x, center_y, center_z))

    print("✅ Partición creada ajustada al visual mesh con orientación vertical")
