﻿# -*- coding: utf-8 -*-

import omni.ext
import omni.ui as ui
from pxr import Usd, UsdGeom, Gf
import omni.usd
import os
import subprocess
import math

class UsdToIdfExtension(omni.ext.IExt):

    def on_startup(self, ext_id):
        print("[usd.to.idf] Extension iniciada.")
        self._window = ui.Window("USD to IDF Exporter", width=300, height=100)

        with self._window.frame:
            with ui.VStack(spacing=10):
                ui.Label("Exportar modelo USD a IDF:")

                with ui.HStack():
                    ui.Button("Exportar a IDF", clicked_fn=self.export_to_idf)
                    ui.Button("Simular", clicked_fn=self.run_energyplus)

    def export_to_idf(self):
        self._last_idf_path = output_path
        stage = omni.usd.get_context().get_stage()
        if not stage:
            print("⚠️ No hay ninguna escena activa.")
            return

        surfaces = []
        zones = {}

        for prim in stage.Traverse():
            if prim.IsA(UsdGeom.Mesh):
                path_str = str(prim.GetPath())
                if not (
                    "/FunctionalBlock/ThermalZone/Zone" in path_str
                    or "/ThermalZone/Zone" in path_str
                ):
                    continue

                parts = path_str.split("/")
                if len(parts) < 5:
                    continue
                zone_name = parts[4]

                geom = UsdGeom.Mesh(prim)
                name = prim.GetName()
                surface_type = prim.GetAttribute("surfaceType").Get()
                boundary = prim.GetAttribute("boundaryCondition").Get()
                material = prim.GetAttribute("material").Get() if prim.HasAttribute("material") else "DefaultMaterial"
                raw_vertices = geom.GetPointsAttr().Get()
                vertices = [(float(v[0]), float(v[1]), float(v[2])) for v in raw_vertices if len(v) == 3]

                if (surface_type or "Wall").lower() == "floor":
                    # Ordenar los vértices según Z constante y antihorario (Y, X)
                    vertices = sorted(vertices, key=lambda v: (v[1], v[0]))

                zones.setdefault(zone_name, []).append({
                    "name": name,
                    "type": surface_type or "Wall",
                    "boundary": boundary or "Outdoors",
                    "vertices": [(round(v[0], 5), round(v[1], 5), round(v[2], 5)) for v in vertices],
                    "material": material
                })

        # Detección de paredes interzonas
        zone_extents = {}
        for zone_name in zones:
            prim = stage.GetPrimAtPath(f"/World/FunctionalBlock/ThermalZone/{zone_name}")
            bbox = UsdGeom.Boundable(prim).ComputeWorldBound(0, UsdGeom.Tokens.default_)
            box = bbox.GetBox()
            zone_extents[zone_name] = (box.GetMin(), box.GetMax())

        processed_pairs = set()

        for zone_a in zones:
            for zone_b in zones:
                if zone_a == zone_b or (zone_b, zone_a) in processed_pairs:
                    continue

                min_a, max_a = zone_extents[zone_a]
                min_b, max_b = zone_extents[zone_b]

                if (math.isclose(max_a[0], min_b[0], abs_tol=0.01) or math.isclose(min_a[0], max_b[0], abs_tol=0.01)):
                    y_min = min(min_a[1], min_b[1])
                    y_max = max(max_a[1], max_b[1])
                    z_min = min(min_a[2], min_b[2])
                    z_max = max(max_a[2], max_b[2])
                    x = (max_a[0] + min_b[0]) / 2 if math.isclose(max_a[0], min_b[0], abs_tol=0.01) else (min_a[0] + max_b[0]) / 2

                    vertices = [
                        (x, y_min, z_min),
                        (x, y_max, z_min),
                        (x, y_max, z_max),
                        (x, y_min, z_max),
                    ]

                    surface_a = f"Partition_{zone_a}_to_{zone_b}"
                    surface_b = f"Partition_{zone_b}_to_{zone_a}"

                    zones[zone_a].append({
                        "name": surface_a,
                        "type": "Wall",
                        "boundary": "Surface",
                        "outside_object": surface_b,
                        "vertices": [(round(v[0], 5), round(v[1], 5), round(v[2], 5)) for v in vertices],
                        "material": "DefaultMaterial"
                    })

                    zones[zone_b].append({
                        "name": surface_b,
                        "type": "Wall",
                        "boundary": "Surface",
                        "outside_object": surface_a,
                        "vertices": [(round(v[0], 5), round(v[1], 5), round(v[2], 5)) for v in reversed(vertices)],
                        "material": "DefaultMaterial"
                    })

                    processed_pairs.add((zone_a, zone_b))

        output_path = os.path.expanduser("C:/Users/pablo/OneDrive/Escritorio/energy_model.idf")

        with open(output_path, "w") as f:
            f.write("Version,24.2;\n\n")
            f.write("Timestep,4;\n\n")

            f.write("RunPeriod,\n")
            f.write("  Run Period 1,\n")
            f.write("  1,\n")
            f.write("  1,\n")
            f.write("  ,\n")
            f.write("  12,\n")
            f.write("  31,\n")
            f.write("  ,\n")
            f.write("  Tuesday,\n")
            f.write("  Yes,\n")
            f.write("  Yes,\n")
            f.write("  No,\n")
            f.write("  Yes,\n")
            f.write("  Yes;\n\n")

            f.write("GlobalGeometryRules,\n")
            f.write("  LowerLeftCorner,\n")
            f.write("  CounterClockWise,\n")
            f.write("  Relative;\n\n")

            f.write("Material,\n")
            f.write("  DefaultMaterial,\n")
            f.write("  Rough,\n")
            f.write("  0.1,\n")
            f.write("  0.9,\n")
            f.write("  800,\n")
            f.write("  900,\n")
            f.write("  0.9,\n")
            f.write("  0.7,\n")
            f.write("  0.7;\n\n")

            f.write("Construction,\n")
            f.write("  DefaultMaterial,\n")
            f.write("  DefaultMaterial;\n\n")

            f.write("Building,\n  MyBuilding, 0, City, 0.04, 0.04;\n\n")

            for zone_name in zones:
                f.write(f"Zone,\n  {zone_name}, 0, 0, 0, 1;\n\n")

            for zone_name, zone_surfaces in zones.items():
                for idx, s in enumerate(zone_surfaces):
                    num_vertices = len(s["vertices"])
                    if num_vertices < 3 or any(len(v) != 3 for v in s["vertices"]):
                        print(f"⚠️ Superficie {s['name']} descartada por vértices inválidos.")
                        continue

                    surface_name = f"{zone_name}_{s['name']}"
                    is_floor = s["type"].lower() == "floor"
                    sun_exposure = "NoSun" if is_floor else "SunExposed"
                    wind_exposure = "NoWind" if is_floor else "WindExposed"

                    boundary_condition = "Ground" if is_floor else s['boundary']

                    f.write("BuildingSurface:Detailed,\n")
                    f.write(f"  {surface_name},           !- Name\n")
                    f.write(f"  {s['type']},              !- Surface Type\n")
                    f.write(f"  {s['material']},          !- Construction Name\n")
                    f.write(f"  {zone_name},              !- Zone Name\n")
                    f.write("  ,                        !- Space Name\n")
                    f.write(f"  {boundary_condition},          !- Outside Boundary Condition\n")
                    f.write(f"  {s.get('outside_object', '')},          !- Outside Boundary Condition Object\n")
                    f.write(f"  {sun_exposure},          !- Sun Exposure\n")
                    f.write(f"  {wind_exposure},         !- Wind Exposure\n")
                    f.write("  0.5,                     !- View Factor to Ground\n")
                    f.write(f"  {num_vertices},          !- Number of Vertices\n")

                    for i, vertex in enumerate(s["vertices"]):
                        x, y, z = vertex
                        comma = "," if i < num_vertices - 1 else ";"
                        f.write(f"  {x:.5f},{y:.5f},{z:.5f}{comma}  !- X,Y,Z ==> Vertex {i + 1} {{m}}\n")

                    f.write("\n")

            f.write("Output:Variable,\n  *,\n  Zone Mean Air Temperature,\n  hourly;\n\n")
            f.write("Output:Table:SummaryReports,\n  AllSummary;\n")

        print(f"✅ Archivo IDF exportado en: {output_path}")

    def run_energyplus(self):
        idf_file = getattr(self, "_last_idf_path", None)
        if not idf_file or not os.path.exists(idf_file):
            print("❌ No hay IDF exportado recientemente.")
            return
        weather_file = "C:/EnergyPlusV24-2-0/WeatherData/USA_IL_Chicago-OHare.Intl.AP.725300_TMY3.epw"
        output_dir = "C:/EnergyPlusV24-2-0/Output"
        energyplus_exe = "C:/EnergyPlusV24-2-0/energyplus.exe"

        if not os.path.exists(idf_file):
            print("❌ No se encontró el archivo IDF.")
            return

        try:
            subprocess.run([
                energyplus_exe,
                "-r",
                "-w", weather_file,
                "-d", output_dir,
                idf_file
            ], check=True)
            print("✅ Simulación ejecutada con éxito.")
        except subprocess.CalledProcessError as e:
            print(f"❌ Error al ejecutar EnergyPlus: {e}")

    def on_shutdown(self):
        print("[Proyecto.usd.idf] Proyecto usd idf shutdown")
