# -*- coding: utf-8 -*-

import omni.usd
import omni.kit.commands
import omni.kit.actions.core
from .evaluators import get_geometry_mesh_prim_list

def register_actions(extension_id, cls, get_self_fn):
    print(f"[Custom Mesh] Registrando acciones con extension_id = {extension_id}")

    def create_mesh_prim(prim_type, **kwargs):
        usd_context = omni.usd.get_context()
        with omni.kit.usd.layers.active_authoring_layer_context(usd_context):
            attributes = kwargs.get("attributes", {})
            omni.kit.commands.execute(
                "custom.kit.primitive.mesh.command.CreateMeshPrimWithCustomXform",
                prim_type=prim_type,
                above_ground=True,
                attributes={"up_axis": "X"}
            )


    # actions
    for prim in get_geometry_mesh_prim_list():
        omni.kit.actions.core.get_action_registry().register_action(
            extension_id,
            f"create_mesh_prim_{prim.lower()}",
            lambda p=prim: create_mesh_prim(p),
            display_name=f"Create Mesh Prim {prim}",
            description=f"Create Mesh Prim {prim}",
            tag="Create Mesh Prim",
        )
        print(f"[Custom Mesh] Accion registrada: create_mesh_prim_{prim.lower()}")

    if get_self_fn() is not None:
        omni.kit.actions.core.get_action_registry().register_action(
            extension_id,
            "show_setting_window",
            get_self_fn().show_setting_window,
            display_name="Show Settings Window",
            description="Show Settings Window",
            tag="Show Settings Window",
        )
        print("[Custom Mesh] Accion registrada: show_setting_window")

def deregister_actions(extension_id):
    action_registry = omni.kit.actions.core.get_action_registry()
    action_registry.deregister_all_actions_for_extension(extension_id)
