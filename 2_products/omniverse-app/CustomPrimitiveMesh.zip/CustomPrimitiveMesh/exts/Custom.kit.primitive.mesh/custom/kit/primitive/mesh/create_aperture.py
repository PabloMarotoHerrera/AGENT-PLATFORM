﻿from pxr import UsdGeom, Sdf, Gf, Vt
import omni.usd

def create_aperture(type_: str, center: Gf.Vec3f, width: float, height: float, sill: float, normal: Gf.Vec3f):
    stage = omni.usd.get_context().get_stage()
    root = "/World/Design/Apertures"
    if not stage.GetPrimAtPath(root).IsValid():
        UsdGeom.Xform.Define(stage, root)

    path = omni.usd.get_stage_next_free_path(stage, f"{root}/{type_.capitalize()}", True)
    xform = UsdGeom.Xform.Define(stage, path)

    prim = xform.GetPrim()
    prim.CreateAttribute("aperture:type", Sdf.ValueTypeNames.String).Set(type_)
    prim.CreateAttribute("aperture:width", Sdf.ValueTypeNames.Float).Set(width)
    prim.CreateAttribute("aperture:height", Sdf.ValueTypeNames.Float).Set(height)
    prim.CreateAttribute("aperture:sillHeight", Sdf.ValueTypeNames.Float).Set(sill)

    # Visual: un rectángulo fino (plane) en el centro, orientado al muro
    mesh = UsdGeom.Mesh.Define(stage, f"{path}/Preview")
    w = width / 2.0
    h = height / 2.0
    z = 0.0
    pts = [Gf.Vec3f(-w, 0, sill - h), Gf.Vec3f(w, 0, sill - h), Gf.Vec3f(w, 0, sill + h), Gf.Vec3f(-w, 0, sill + h)]
    mesh.GetPointsAttr().Set(Vt.Vec3fArray(pts))
    mesh.GetFaceVertexCountsAttr().Set(Vt.IntArray([4]))
    mesh.GetFaceVertexIndicesAttr().Set(Vt.IntArray([0,1,2,3]))
    mesh.GetNormalsAttr().Set(Vt.Vec3fArray([Gf.Vec3f(0,1,0)]*4))
    mesh.SetNormalsInterpolation("vertex")
    mesh.GetPrim().CreateAttribute("doubleSided", Sdf.ValueTypeNames.Bool).Set(True)

    # Transform: mover al centro (orientación al muro la añadimos luego con look-at / quaternion)
    xf = UsdGeom.Xformable(prim)
    xf.AddTranslateOp().Set(Gf.Vec3f(center[0], center[1], center[2]))

    print(f"✅ Aperture creada: {path}")
    return path
